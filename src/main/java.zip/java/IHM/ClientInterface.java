package IHM;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.io.InputStreamReader;
import java.net.Socket;

public class ClientInterface extends JFrame {
    private JPanel mainPanel;
    private JTextField usernameTextField;
    private JButton connectButton;
    private JTextArea chatTextArea;
    private JTextField messageTextField;
    private JButton sendButton;
    private JScrollPane chatScrollPane;
    private PrintWriter out;
    private BufferedReader in;
    private Socket socket;

    private String serverIP = "127.0.0.1";
    private int serverPort = 1235;
    public ClientInterface() {

        setTitle("Chat Client");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(mainPanel);
        pack();

        connectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                connectToServer();
            }
        });

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });

        messageTextField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });
    }

    private void connectToServer() {
        if (socket != null && socket.isConnected()) {
            JOptionPane.showMessageDialog(this, "You are already connected to the server.");
            return;
        }

        try {
            socket = new Socket(serverIP, serverPort);
            out = new PrintWriter(socket.getOutputStream(), true);
            in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            JOptionPane.showMessageDialog(this, "Connected to the chat server.");

            Thread serverListener = new Thread(() -> {
                try {
                    String inputLine;
                    while ((inputLine = in.readLine()) != null) {
                        appendMessage(inputLine);
                    }
                } catch (IOException e) {
                    appendMessage("Error receiving messages from server: " + e.getMessage());
                }
            });
            serverListener.start();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error connecting to the chat server: " + e.getMessage());
        }
    }

    private void sendMessage() {
        String message = messageTextField.getText().trim();
        if (!message.isEmpty()) {
            String username = usernameTextField.getText().trim();
            if (username.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a username.");
                return;
            }

            String date = new SimpleDateFormat("HH-mm").format(new Date());
            out.println(username + ":" + message + ":" + date);
            messageTextField.setText("");
        }
    }

    public void setOut(PrintWriter out) {
        this.out = out;
    }

    public void setIn(BufferedReader in) {
        this.in = in;
    }

    public void appendMessage(String message) {
        chatTextArea.append(message + "\n");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new ClientInterface().setVisible(true);
            }
        });
    }
}
